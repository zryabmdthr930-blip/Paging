# LingoRise

Your AI English Coach.

## Current architecture
- Frontend: HTML, CSS, JavaScript
- Backend: Python + FastAPI
- Database: SQLite by default
- Authentication: Google Sign-In + server-side JWT
- Level test: 10-question placement test saved to SQL
- Dashboard: level, lessons, progress
- AI Tutor: backend endpoint; requires an LLM API key
- Payments: manual activation through WhatsApp

## Google setup
1. Create a Google OAuth Web Client ID in Google Cloud Console.
2. Put it in `backend/.env` as `GOOGLE_CLIENT_ID=...`.
3. Put the same client ID in the frontend deployment config as `window.LINGORISE_GOOGLE_CLIENT_ID` before loading `app.js`.
4. Add your real site domain to Google's authorized JavaScript origins.

## Run backend
```bash
cd backend
python -m venv .venv
# activate the environment
pip install -r requirements.txt
uvicorn main:app --reload
```

API docs: `http://127.0.0.1:8000/docs`

## Payment flow
User selects Premium -> WhatsApp opens with the plan/email -> support sends available payment methods -> user sends proof -> admin verifies -> account subscription is manually changed to Premium.

Do not put secrets, Google client secrets, or LLM API keys in frontend JavaScript.
