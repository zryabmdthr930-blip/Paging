const WHATSAPP_NUMBER = '249120038819';
const API_BASE = window.LINGORISE_API || 'http://127.0.0.1:8000';
const state = { lang: 'ar', quizIndex: 0, quizScore: 0, selectedAnswer: null };
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const quizQuestions = [
  { q: 'Choose the correct sentence:', a: ['I am student.', 'I am a student.', 'I student am.'], c: 1 },
  { q: 'She ___ to work every day.', a: ['go', 'goes', 'going'], c: 1 },
  { q: 'I have lived here ___ 2022.', a: ['for', 'since', 'during'], c: 1 },
  { q: 'If I had more time, I ___ more.', a: ['travel', 'will travel', 'would travel'], c: 2 },
  { q: 'Which is closest to “rapid”?', a: ['slow', 'fast', 'quiet'], c: 1 },
  { q: 'By the time we arrived, the film ___.', a: ['started', 'had started', 'has started'], c: 1 },
  { q: 'He suggested ___ earlier.', a: ['leave', 'to leave', 'leaving'], c: 2 },
  { q: 'The report was ___ detailed that we needed extra time.', a: ['so', 'such', 'too'], c: 0 },
  { q: '“Despite the rain” means:', a: ['Because it rained', 'Although it rained', 'Before it rained'], c: 1 },
  { q: 'Choose the most natural sentence:', a: ['Had I known, I would have helped.', 'Had I knew, I would help.', 'If I know, I helped.'], c: 0 }
];

function applyLanguage(lang) {
  state.lang = lang;
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  $$('[data-ar][data-en]').forEach((element) => { element.innerHTML = element.dataset[lang]; });
  $$('[data-ar-placeholder][data-en-placeholder]').forEach((element) => {
    element.placeholder = lang === 'ar' ? element.dataset.arPlaceholder : element.dataset.enPlaceholder;
  });
  $$('.lang-btn').forEach((button) => button.classList.toggle('active', button.dataset.lang === lang));
  document.title = lang === 'ar' ? 'LingoRise — مدربك الشخصي للإنجليزية' : 'LingoRise — Your AI English Coach';
  if ($('#quiz-modal')?.classList.contains('is-open')) renderQuestion();
}

function showToast(message) {
  const toast = $('#toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('show'), 3200);
}

function openModal(id) {
  const modal = $(`#${id}`);
  if (!modal) return;
  modal.classList.add('is-open');
  modal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('modal-open');
}

function closeModal(modal) {
  modal.classList.remove('is-open');
  modal.setAttribute('aria-hidden', 'true');
  if (!$$('.app-modal.is-open').length) document.body.classList.remove('modal-open');
}

function buildWhatsAppLink(plan = 'Premium') {
  const email = $('#pricing-email')?.value.trim() || '';
  const message = state.lang === 'ar'
    ? `مرحباً LingoRise، أريد ${plan === 'Support' ? 'الاستفسار عن المنصة' : `الاشتراك في خطة ${plan}`} — بريدي: ${email || 'سأرسله لكم هنا'}`
    : `Hi LingoRise, I’d like to ${plan === 'Support' ? 'ask about the platform' : `subscribe to the ${plan} plan`} — my email: ${email || 'I’ll share it here'}`;
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

function openWhatsApp(plan) {
  const email = $('#pricing-email')?.value.trim();
  if (plan === 'Premium' && email && !/^\S+@\S+\.\S+$/.test(email)) {
    showToast(state.lang === 'ar' ? 'اكتب بريدًا إلكترونيًا صحيحًا أولًا.' : 'Please enter a valid email first.');
    $('#pricing-email').focus();
    return;
  }
  window.open(buildWhatsAppLink(plan), '_blank', 'noopener,noreferrer');
}

function correctSentence() {
  const input = $('#sentence');
  const result = $('#correction-result');
  const sentence = input.value.trim();
  if (!sentence) { showToast(state.lang === 'ar' ? 'اكتب جملة قصيرة للتجربة.' : 'Write a short sentence to try it.'); input.focus(); return; }
  const lower = sentence.toLowerCase();
  const known = lower.includes('interesting in learn') || lower.includes('interested in learn');
  const corrected = known ? 'I am interested in learning English.' : `${sentence.replace(/[.!?]*$/, '')}.`;
  const explanation = known
    ? (state.lang === 'ar' ? 'نستخدم interested لوصف شعور الشخص، وبعد in يأتي الفعل بصيغة -ing.' : 'Use interested to describe how you feel, and use the -ing form after in.')
    : (state.lang === 'ar' ? 'جرّب قراءة الجملة بصوت عالٍ، ثم راجع ترتيب الكلمات واختيار الفعل.' : 'Read it aloud, then check the word order and verb choice.');
  result.innerHTML = `<div class="result-title"><span class="check-badge">✓</span><span>${state.lang === 'ar' ? 'اقتراح أفضل' : 'A better way'}</span></div><p class="wrong-line">${escapeHtml(sentence)}</p><p class="right-line">${escapeHtml(corrected)}</p><p class="explanation">${explanation}</p>`;
}

function escapeHtml(value) { return value.replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char])); }


async function loginWithGoogleCredential(credential) {
  const note = $('#login-note') || $('#trial-note');
  try {
    const response = await fetch(`${API_BASE}/api/auth/google`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ credential })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || 'Google login failed');
    localStorage.setItem('lingorise_token', data.token);
    localStorage.setItem('lingorise_user', JSON.stringify(data.user));
    location.href = 'dashboard.html';
  } catch (error) {
    if (note) note.textContent = state.lang === 'ar' ? `تعذر تسجيل الدخول عبر Google: ${error.message}` : `Google login failed: ${error.message}`;
  }
}

function initGoogleAuth() {
  const clientId = window.LINGORISE_GOOGLE_CLIENT_ID;
  if (!clientId || !window.google?.accounts?.id) return;
  window.google.accounts.id.initialize({ client_id: clientId, callback: (response) => loginWithGoogleCredential(response.credential) });
  ['google-trial-button','google-login-button'].forEach((id) => {
    const el = document.getElementById(id);
    if (!el || el.dataset.rendered) return;
    window.google.accounts.id.renderButton(el, { theme: 'outline', size: 'large', width: 320, text: 'continue_with' });
    el.dataset.rendered = '1';
  });
}

function openLogin() {
  $('#login-form')?.reset();
  setTimeout(initGoogleAuth, 200);
  $('#login-note').textContent = '';
  openModal('login-modal');
}

async function loginUser(event) {
  event.preventDefault();
  const note = $('#login-note');
  try {
    const response = await fetch(`${API_BASE}/api/auth/login`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: $('#login-email').value.trim(), password: $('#login-password').value })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || 'Login failed');
    localStorage.setItem('lingorise_token', data.token);
    localStorage.setItem('lingorise_user', JSON.stringify(data.user));
    location.href = 'dashboard.html';
  } catch (error) {
    note.textContent = state.lang === 'ar' ? `تعذر تسجيل الدخول: ${error.message}` : `Login failed: ${error.message}`;
  }
}

function startTrial() { openModal('trial-modal'); setTimeout(() => { initGoogleAuth(); $('#trial-name')?.focus(); }, 200); }

async function saveTrialAccount(event) {
  event.preventDefault();
  const name = $('#trial-name').value.trim();
  const email = $('#trial-email').value.trim().toLowerCase();
  const password = $('#trial-password').value;
  if (password.length < 6) { $('#trial-note').textContent = state.lang === 'ar' ? 'كلمة المرور يجب أن تكون 6 أحرف على الأقل.' : 'Password must be at least 6 characters.'; return; }
  $('#trial-note').textContent = state.lang === 'ar' ? 'جاري إنشاء الحساب…' : 'Creating your account…';
  try {
    const response = await fetch(`${API_BASE}/api/auth/register`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || 'Registration failed');
    localStorage.setItem('lingorise_token', data.token);
    localStorage.setItem('lingorise_user', JSON.stringify(data.user));
    $('#trial-note').textContent = state.lang === 'ar' ? 'تم إنشاء الحساب بنجاح. نفتح اختبار المستوى الآن…' : 'Account created. Opening the level test…';
    setTimeout(() => { closeModal($('#trial-modal')); openQuiz(); }, 500);
  } catch (error) {
    $('#trial-note').textContent = state.lang === 'ar' ? `تعذر إنشاء الحساب: ${error.message}` : `Could not create account: ${error.message}`;
  }
}

function openQuiz() {
  state.quizIndex = 0; state.quizScore = 0; state.selectedAnswer = null;
  $('#quiz-result').hidden = true; $('#quiz-next').hidden = false;
  renderQuestion(); openModal('quiz-modal');
}

function renderQuestion() {
  const item = quizQuestions[state.quizIndex];
  if (!item) return;
  $('#quiz-counter').textContent = `${String(state.quizIndex + 1).padStart(2, '0')} / ${quizQuestions.length}`;
  $('#quiz-question').textContent = item.q;
  $('#quiz-answers').innerHTML = item.a.map((answer, index) => `<button class="quiz-answer" type="button" data-answer="${index}">${String.fromCharCode(65 + index)}  ${escapeHtml(answer)}</button>`).join('');
  state.selectedAnswer = null;
  $$('.quiz-answer').forEach(btn => btn.addEventListener('click', () => {
    state.selectedAnswer = Number(btn.dataset.answer);
    $$('.quiz-answer').forEach(x => x.classList.remove('selected'));
    btn.classList.add('selected');
  }));
  $('#quiz-progress-bar').style.width = `${(state.quizIndex / quizQuestions.length) * 100}%`;
  $('#quiz-next').querySelector('[data-ar]').textContent = state.lang === 'ar' ? 'التالي' : 'Next';
}

function nextQuizQuestion() {
  if (state.selectedAnswer === null) { showToast(state.lang === 'ar' ? 'اختر إجابة أولًا.' : 'Choose an answer first.'); return; }
  if (state.selectedAnswer === quizQuestions[state.quizIndex].c) state.quizScore++;
  if (state.quizIndex < quizQuestions.length - 1) { state.quizIndex++; renderQuestion(); return; }
  finishQuiz();
}

function finishQuiz() {
  const score = state.quizScore;
  const level = score <= 2 ? 'A1' : score <= 4 ? 'A2' : score <= 6 ? 'B1' : score <= 8 ? 'B2' : 'C1';
  const user = JSON.parse(localStorage.getItem('lingorise_user') || '{}');
  user.level = level; user.quizScore = score; user.quizCompletedAt = new Date().toISOString();
  localStorage.setItem('lingorise_user', JSON.stringify(user));
  const token = localStorage.getItem('lingorise_token');
  if (token) {
    fetch(`${API_BASE}/api/quiz/result`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ score, total: quizQuestions.length, level })
    }).catch(() => {});
  }
  $('#quiz-progress-bar').style.width = '100%';
  $('#quiz-answers').innerHTML = '';
  $('#quiz-question').textContent = state.lang === 'ar' ? 'نتيجتك جاهزة 🎉' : 'Your result is ready 🎉';
  $('#quiz-result').hidden = false;
  $('#quiz-result').innerHTML = `<strong>${level}</strong><p>${state.lang === 'ar' ? `أجبت بشكل صحيح على ${score} من ${quizQuestions.length}. هذا تقدير مبدئي، ويمكن تحسينه مع استخدام المنصة.` : `You answered ${score} of ${quizQuestions.length} correctly. This is an initial estimate that can improve with practice.`}</p>`;
  $('#quiz-next').hidden = true;
  $('#quiz-result').insertAdjacentHTML('beforeend', '<a class="button button-primary dashboard-link" href="dashboard.html">Open Dashboard ↗</a>');
}

$$('.lang-btn').forEach((button) => button.addEventListener('click', () => applyLanguage(button.dataset.lang)));
$('#correct-btn')?.addEventListener('click', correctSentence);
$('#sentence')?.addEventListener('keydown', (event) => { if (event.key === 'Enter') correctSentence(); });
$$('.whatsapp-button').forEach((button) => button.addEventListener('click', () => openWhatsApp(button.dataset.plan)));

$$('a[href="#trial"]').forEach((link) => link.addEventListener('click', (event) => { event.preventDefault(); startTrial(); }));
$$('a[href="#login"]').forEach((link) => link.addEventListener('click', (event) => { event.preventDefault(); openLogin(); }));
$('#login-form')?.addEventListener('submit', loginUser);
$('#trial-form')?.addEventListener('submit', saveTrialAccount);
$('#quiz-btn')?.addEventListener('click', openQuiz);
$('#quiz-next')?.addEventListener('click', nextQuizQuestion);
$$('[data-close-modal]').forEach((el) => el.addEventListener('click', () => closeModal(el.closest('.app-modal'))));
document.addEventListener('keydown', (event) => { if (event.key === 'Escape') $$('.app-modal.is-open').forEach(closeModal); });

$$('.faq-list details').forEach((detail) => detail.addEventListener('toggle', () => {
  if (detail.open) $$('.faq-list details').filter((other) => other !== detail).forEach((other) => { other.open = false; });
}));

const observer = new IntersectionObserver((entries) => entries.forEach((entry) => { if (entry.isIntersecting) entry.target.classList.add('is-visible'); }), { threshold: .14 });
$$('.feature-card, .step-card, .price-card, .faq-list details').forEach((element) => observer.observe(element));

applyLanguage('ar');

const googleTimer = setInterval(() => { if (window.google?.accounts?.id) { initGoogleAuth(); clearInterval(googleTimer); } }, 500);
setTimeout(() => clearInterval(googleTimer), 15000);
