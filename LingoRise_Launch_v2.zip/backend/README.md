# LingoRise Backend

FastAPI + SQLite backend for real registration, login, user profiles, and level-test results.

## Run

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

API: `http://127.0.0.1:8000`
Docs: `http://127.0.0.1:8000/docs`

The database is created automatically as `lingorise.db` on first run.

## Production note
Set a strong `LINGORISE_SECRET_KEY`, restrict CORS to the real frontend domain, use HTTPS, and move to PostgreSQL before production.
