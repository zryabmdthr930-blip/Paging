from datetime import datetime, timedelta, timezone
import os

import jwt
from fastapi import FastAPI, Depends, HTTPException, status, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import DateTime, ForeignKey, Integer, String, create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker
from pwdlib import PasswordHash

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./lingorise.db")
SECRET_KEY = os.getenv("LINGORISE_SECRET_KEY", "change-this-in-production")
ALGORITHM = "HS256"
ADMIN_KEY = os.getenv("LINGORISE_ADMIN_KEY", "")
FRONTEND_ORIGINS = [x.strip() for x in os.getenv("FRONTEND_ORIGINS", "*").split(",") if x.strip()]

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
password_hash = PasswordHash.recommended()
bearer = HTTPBearer(auto_error=False)

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    google_sub: Mapped[str | None] = mapped_column(String(255), unique=True, nullable=True, index=True)
    plan: Mapped[str] = mapped_column(String(30), default="Free")
    subscription_status: Mapped[str] = mapped_column(String(30), default="inactive")
    level: Mapped[str | None] = mapped_column(String(10), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))

class QuizResult(Base):
    __tablename__ = "quiz_results"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    score: Mapped[int] = mapped_column(Integer)
    total: Mapped[int] = mapped_column(Integer)
    level: Mapped[str] = mapped_column(String(10))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))

class Lesson(Base):
    __tablename__ = "lessons"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    level: Mapped[str] = mapped_column(String(10), index=True)
    title: Mapped[str] = mapped_column(String(180))
    description: Mapped[str] = mapped_column(String(500))
    order: Mapped[int] = mapped_column(Integer)

class LessonProgress(Base):
    __tablename__ = "lesson_progress"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    lesson_id: Mapped[int] = mapped_column(ForeignKey("lessons.id"), index=True)
    completed: Mapped[int] = mapped_column(Integer, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))

Base.metadata.create_all(engine)

app = FastAPI(title="LingoRise API", version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=FRONTEND_ORIGINS, allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

class RegisterRequest(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=6, max_length=128)

class GoogleLoginRequest(BaseModel):
    credential: str = Field(min_length=20)

class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=6, max_length=128)

class QuizRequest(BaseModel):
    score: int = Field(ge=0)
    total: int = Field(gt=0)
    level: str = Field(min_length=2, max_length=10)

class ProgressRequest(BaseModel):
    completed: bool

class TutorRequest(BaseModel):
    message: str = Field(min_length=1, max_length=2000)


def db():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


def make_token(user_id: int) -> str:
    return jwt.encode({"sub": str(user_id), "exp": datetime.now(timezone.utc) + timedelta(days=7)}, SECRET_KEY, algorithm=ALGORITHM)


def current_user(credentials: HTTPAuthorizationCredentials = Depends(bearer), session: Session = Depends(db)) -> User:
    if not credentials:
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user


def seed_lessons(session: Session):
    if session.query(Lesson).count():
        return
    rows = [
        ("A1", "Introducing yourself", "Basic introductions, names and countries.", 1),
        ("A1", "Daily routines", "Talk about your day using the present simple.", 2),
        ("A2", "Past experiences", "Use the past simple to describe experiences.", 1),
        ("A2", "Making plans", "Talk about future plans and arrangements.", 2),
        ("B1", "Small talk at work", "Start and maintain natural workplace conversations.", 1),
        ("B1", "Giving opinions", "Express, support and soften your opinions.", 2),
        ("B2", "Professional writing", "Write clear emails and workplace messages.", 1),
        ("B2", "Presenting ideas", "Structure and deliver a short professional presentation.", 2),
        ("C1", "Nuance and precision", "Choose precise language for complex ideas.", 1),
        ("C1", "Advanced discussion", "Discuss abstract topics with natural fluency.", 2),
    ]
    session.add_all([Lesson(level=a, title=b, description=c, order=d) for a, b, c, d in rows])
    session.commit()

with SessionLocal() as _session:
    seed_lessons(_session)

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "LingoRise API", "version": "2.0.0"}

@app.post("/api/auth/register")
def register(data: RegisterRequest, session: Session = Depends(db)):
    email = data.email.lower()
    if session.query(User).filter(User.email == email).first():
        raise HTTPException(status_code=409, detail="Email already registered")
    user = User(name=data.name.strip(), email=email, password_hash=password_hash.hash(data.password))
    session.add(user)
    session.commit()
    session.refresh(user)
    return {"token": make_token(user.id), "user": {"id": user.id, "name": user.name, "email": user.email, "level": user.level, "plan": user.plan, "subscription_status": user.subscription_status}}

@app.post("/api/auth/google")
def google_login(data: GoogleLoginRequest, session: Session = Depends(db)):
    client_id = os.getenv("GOOGLE_CLIENT_ID")
    if not client_id:
        raise HTTPException(status_code=503, detail="Google login is not configured on the server")
    try:
        from google.oauth2 import id_token
        from google.auth.transport import requests as google_requests
        info = id_token.verify_oauth2_token(data.credential, google_requests.Request(), client_id)
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid Google credential")
    email = (info.get("email") or "").lower().strip()
    if not email or not info.get("email_verified"):
        raise HTTPException(status_code=400, detail="A verified Google email is required")
    user = session.query(User).filter(User.email == email).first()
    if not user:
        user = User(name=info.get("name") or email.split("@")[0], email=email, password_hash=None, google_sub=info.get("sub"))
        session.add(user)
    else:
        user.google_sub = info.get("sub") or user.google_sub
    session.commit()
    session.refresh(user)
    return {"token": make_token(user.id), "user": {"id": user.id, "name": user.name, "email": user.email, "level": user.level, "plan": user.plan, "subscription_status": user.subscription_status}}

@app.post("/api/auth/login")
def login(data: LoginRequest, session: Session = Depends(db)):
    user = session.query(User).filter(User.email == data.email.lower()).first()
    if not user or not user.password_hash or not password_hash.verify(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    return {"token": make_token(user.id), "user": {"id": user.id, "name": user.name, "email": user.email, "level": user.level, "plan": user.plan, "subscription_status": user.subscription_status}}

@app.get("/api/me")
def me(user: User = Depends(current_user)):
    return {"id": user.id, "name": user.name, "email": user.email, "level": user.level, "plan": user.plan, "subscription_status": user.subscription_status}

@app.post("/api/quiz/result")
def save_quiz(data: QuizRequest, user: User = Depends(current_user), session: Session = Depends(db)):
    if data.score > data.total:
        raise HTTPException(status_code=400, detail="Score cannot exceed total")
    result = QuizResult(user_id=user.id, score=data.score, total=data.total, level=data.level)
    user.level = data.level
    session.add(result)
    session.commit()
    return {"saved": True, "level": data.level, "score": data.score, "total": data.total}

@app.get("/api/dashboard")
def dashboard(user: User = Depends(current_user), session: Session = Depends(db)):
    lessons = session.query(Lesson).filter(Lesson.level == (user.level or "A1")).order_by(Lesson.order).all()
    progress = {p.lesson_id: bool(p.completed) for p in session.query(LessonProgress).filter(LessonProgress.user_id == user.id).all()}
    latest = session.query(QuizResult).filter(QuizResult.user_id == user.id).order_by(QuizResult.created_at.desc()).first()
    return {
        "user": {"id": user.id, "name": user.name, "email": user.email, "level": user.level or "A1"},
        "quiz": {"score": latest.score, "total": latest.total, "level": latest.level} if latest else None,
        "lessons": [{"id": x.id, "title": x.title, "description": x.description, "completed": progress.get(x.id, False)} for x in lessons],
    }

@app.post("/api/lessons/{lesson_id}/progress")
def update_progress(lesson_id: int, data: ProgressRequest, user: User = Depends(current_user), session: Session = Depends(db)):
    lesson = session.get(Lesson, lesson_id)
    if not lesson:
        raise HTTPException(status_code=404, detail="Lesson not found")
    row = session.query(LessonProgress).filter(LessonProgress.user_id == user.id, LessonProgress.lesson_id == lesson_id).first()
    if not row:
        row = LessonProgress(user_id=user.id, lesson_id=lesson_id)
        session.add(row)
    row.completed = int(data.completed)
    row.updated_at = datetime.now(timezone.utc)
    session.commit()
    return {"saved": True, "lesson_id": lesson_id, "completed": data.completed}

class SubscriptionRequest(BaseModel):
    plan: str = Field(default="Premium", min_length=2, max_length=30)

@app.post("/api/subscription/request")
def subscription_request(data: SubscriptionRequest, user: User = Depends(current_user), session: Session = Depends(db)):
    if data.plan != "Premium":
        raise HTTPException(status_code=400, detail="Unsupported plan")
    user.plan = data.plan
    user.subscription_status = "pending_payment"
    session.commit()
    return {"requested": True, "plan": user.plan, "subscription_status": user.subscription_status}

class SubscriptionActivateRequest(BaseModel):
    email: EmailStr

@app.post("/api/admin/subscription/activate")
def activate_subscription(data: SubscriptionActivateRequest, x_admin_key: str | None = Header(default=None), session: Session = Depends(db)):
    if not ADMIN_KEY or x_admin_key != ADMIN_KEY:
        raise HTTPException(status_code=403, detail="Admin authorization required")
    user = session.query(User).filter(User.email == data.email.lower()).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.plan = "Premium"
    user.subscription_status = "active"
    session.commit()
    return {"activated": True, "email": user.email, "plan": user.plan, "subscription_status": user.subscription_status}

@app.post("/api/tutor/chat")
def tutor_chat(data: TutorRequest, user: User = Depends(current_user)):
    """AI endpoint. Add OPENAI_API_KEY on the server to enable an LLM provider."""
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return {"reply": "AI Tutor is ready, but the server administrator still needs to add the LLM API key.", "configured": False}
    try:
        import httpx
        model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        response = httpx.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {api_key}"},
            json={"model": model, "temperature": 0.4, "messages": [
                {"role": "system", "content": f"You are LingoRise, an English tutor. Student level: {user.level or 'A1'}. Correct mistakes briefly, explain simply, then continue the conversation."},
                {"role": "user", "content": data.message}
            ]},
            timeout=30,
        )
        response.raise_for_status()
        body = response.json()
        return {"reply": body["choices"][0]["message"]["content"], "configured": True}
    except Exception:
        raise HTTPException(status_code=502, detail="AI provider is temporarily unavailable")
